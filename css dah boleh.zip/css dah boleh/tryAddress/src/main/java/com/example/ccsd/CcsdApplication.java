package com.example.ccsd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class CcsdApplication {

    public static void main(String[] args) {
        SpringApplication.run(CcsdApplication.class, args);
    }

}