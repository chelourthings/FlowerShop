package com.example.ccsd.Service;

import com.example.ccsd.Model.CartItem;
import com.example.ccsd.Model.Product;
import com.example.ccsd.Model.User;
import com.example.ccsd.Repository.CartItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CartService {

    @Autowired
    private CartItemRepository cartItemRepository;

    public void addToCart(Product product, User user) {
        Optional<CartItem> existingCartItem = cartItemRepository.findAll().stream()
                .filter(cartItem -> cartItem.getProduct().getId().equals(product.getId()) && cartItem.getUser().equals(user))
                .findFirst();

        if (existingCartItem.isPresent()) {
            CartItem cartItem = existingCartItem.get();
            cartItem.setQuantity(cartItem.getQuantity() + 1);
            cartItem.setTotalPrice(cartItem.getQuantity() * product.getPrice());  // Update totalPrice
            cartItemRepository.save(cartItem);
        } else {
            CartItem cartItem = new CartItem();
            cartItem.setProduct(product);
            cartItem.setQuantity(1); // default quantity for new items
            cartItem.setUser(user);  // Set the user
            cartItem.setTotalPrice(product.getPrice());  // Set initial totalPrice
            cartItemRepository.save(cartItem);
        }
    }

    public List<CartItem> getCartItems(User user) {
        return cartItemRepository.findAll().stream()
                .filter(cartItem -> cartItem.getUser().equals(user))
                .toList();
    }

    public void updateQuantity(Long id, int quantity) {
        CartItem cartItem = cartItemRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid cart item Id:" + id));
        cartItem.setQuantity(quantity);
        cartItem.setTotalPrice(quantity * cartItem.getProduct().getPrice());  // Update totalPrice
        cartItemRepository.save(cartItem);
    }

    public void removeFromCart(Long id) {
        cartItemRepository.deleteById(id);
    }

//    public void clearCart(User user) {
//        List<CartItem> cartItems = cartItemRepository.findByUserId(user);
//        cartItemRepository.deleteAll(cartItems);
////        cartItemRepository.findByUserId(user.getId());
//    }

    public void clearCart(User user) {
        // Extract the user ID from the User object
        Long userId = user.getId();

        // Retrieve all cart items for the given user ID
        List<CartItem> cartItems = cartItemRepository.findByUserId(userId);

        // Delete all the retrieved cart items
        cartItemRepository.deleteAll(cartItems);
    }

    public double calculateTotalPrice(User user) {
        List<CartItem> cartItems = cartItemRepository.findAll().stream()
                .filter(cartItem -> cartItem.getUser().equals(user))
                .toList();

        return cartItems.stream()
                .mapToDouble(CartItem::getTotalPrice)
                .sum();
    }
}