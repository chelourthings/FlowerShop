package com.example.ccsd.Controller;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.example.ccsd.Model.CartItem;
import com.example.ccsd.Model.User;
import com.example.ccsd.security.CustomUserDetails;
import com.example.ccsd.Service.CartService;
import com.example.ccsd.Service.PurchaseService;
import com.example.ccsd.Service.UserService;

import java.util.List;

@Controller
public class CheckoutController {

    private final CartService cartService;
    private final PurchaseService purchaseService;
    private final UserService userService;

    // Constructor injection
    public CheckoutController(CartService cartService, PurchaseService purchaseService, UserService userService) {
        this.cartService = cartService;
        this.purchaseService = purchaseService;
        this.userService = userService;
    }

    @GetMapping("/checkout")
    public String checkoutPage(Model model, @AuthenticationPrincipal CustomUserDetails customUserDetails) {
        Long userId = customUserDetails.getId();
        User user = userService.findById(userId);
        List<CartItem> cartItems = cartService.getCartItems(user);
        double totalPrice = cartService.calculateTotalPrice(user);

        model.addAttribute("user", user);
        model.addAttribute("cartItems", cartItems);
        model.addAttribute("totalPrice", totalPrice);

        // Add user address information to the model
        model.addAttribute("addressLine1", user.getAddressLine1());
        model.addAttribute("addressLine2", user.getAddressLine2());
        model.addAttribute("city", user.getCity());
        model.addAttribute("state", user.getState());
        model.addAttribute("postalCode", user.getPostalCode());

        return "checkout";
    }

    @PostMapping("/placeOrder")
    public String placeOrder(@AuthenticationPrincipal CustomUserDetails customUserDetails,
                             @RequestParam("paymentMethod") String paymentMethod,
                             @RequestParam("shippingAddress") String shippingAddress) {
        Long userId = customUserDetails.getId();
        User user = userService.findById(userId);
        List<CartItem> cartItems = cartService.getCartItems(user);
        double totalPrice = cartService.calculateTotalPrice(user);

        purchaseService.createPurchase(user, cartItems, paymentMethod, shippingAddress);

        cartService.clearCart(user);

        return "orderConfirmation";
    }
}

