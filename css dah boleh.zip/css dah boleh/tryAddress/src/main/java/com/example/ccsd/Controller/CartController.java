package com.example.ccsd.Controller;

import com.example.ccsd.Model.CartItem;
import com.example.ccsd.Model.Product;
import com.example.ccsd.Model.User;
import com.example.ccsd.Service.CartService;
import com.example.ccsd.Service.ProductService;
import com.example.ccsd.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @Autowired
    private ProductService productService;

    @Autowired
    private UserService userService;

//    @GetMapping("/view")
//    public String viewCart(Model model, Authentication authentication) {
//        // Get current user
//        User user = getCurrentUser(authentication);
//        model.addAttribute("cartItems", cartService.getCartItems(user));
//        return "cart";
//    }

    @GetMapping("/view")
    public String viewCart(Model model, Authentication authentication) {
        // Get current user
        User user = getCurrentUser(authentication);

        if (user == null) {
            // Redirect to login if no user is authenticated
            return "redirect:/login?sessionExpired";
        }

        // Fetch and add cart items to the model
        List<CartItem> cartItems = cartService.getCartItems(user);
        model.addAttribute("cartItems", cartItems);

        return "cart";
    }

    @PostMapping("/add/{id}")
    public String addToCart(@PathVariable("id") Long id, Authentication authentication) {
        User user = getCurrentUser(authentication);
        Product product = productService.findProductById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid product Id:" + id));
        cartService.addToCart(product, user);
        return "redirect:/cart/view";
    }

    @PostMapping("/update/{id}")
    public String updateQuantity(@PathVariable("id") Long id, @RequestParam("quantity") int quantity) {
        cartService.updateQuantity(id, quantity);
        return "redirect:/cart/view";
    }

    @PostMapping("/remove/{id}")
    public String removeFromCart(@PathVariable("id") Long id) {
        cartService.removeFromCart(id);
        return "redirect:/cart/view";
    }

//    private User getCurrentUser(Authentication authentication) {
//        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
//        // You need to retrieve the User entity from your UserService using userDetails.getUsername()
//        return userService.findByUsername(userDetails.getUsername());
//    }

    private User getCurrentUser(Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return null;
        }

        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        return userService.findByUsername(userDetails.getUsername());
    }
}
