//handles HTTP requests related to user registration and login

package com.example.ccsd.Controller;

import com.example.ccsd.Model.User;
import com.example.ccsd.Service.UserService;
import com.example.ccsd.Dto.UserDto;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.security.Principal;
import java.util.List;

@Controller
public class AuthController {

    @Autowired
    private UserDetailsService userDetailsService;

    private UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping( "/")
    public String homepage(Model model, Principal principal) {
        if(principal !=null) {
            UserDetails userDetails = userDetailsService.loadUserByUsername(principal.getName());
            model.addAttribute("userdetail", userDetails);
        } else {
            model.addAttribute("userdetail", null);
        }
        model.addAttribute("isAuthenticated", principal != null);
        return "index";
    }
//
//    //najwa tambah, call index html
//    @GetMapping("/index")
//    public String homepage(Model model, Principal principal) {
//        UserDetails userDetails = userDetailsService.loadUserByUsername(principal.getName());
//        model.addAttribute("userdetail", userDetails);
//        return "index";
//    }

    @GetMapping("/login")
    public String login(Model model, UserDto userDto) {
        model.addAttribute("user", userDto);
        return "login";
    }

    //handler method to handle user registration form request
    @GetMapping("/register")
    public String showRegistrationForm(Model model, UserDto userDto) {
        model.addAttribute("user", userDto);
        return "register";
    }

    //handle method to handle user registration form submit request
    @PostMapping("/register")
    public String registerSava(@ModelAttribute("user") UserDto userDto, Model model) {
        User user = userService.findByUsername(userDto.getUsername());
        User user2 = userService.findByEmail(userDto.getEmail());
        if (user != null) {
            model.addAttribute("Userexist", user);
            return "register";
        }

        if (user2 != null) {
            model.addAttribute("Emailexist", user2);
            return "register";
        }
        userService.save(userDto);
        return "redirect:/register?success";
    }
}
