//handles HTTP requests related to user registration and login

package com.example.ccsd.Controller;

import com.example.ccsd.Model.Product;
import com.example.ccsd.Model.User;
import com.example.ccsd.Service.ProductService;
import com.example.ccsd.Service.UserService;
import com.example.ccsd.Dto.UserDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

@Controller
public class AuthController {

    private static final Logger logger = LoggerFactory.getLogger(ProductController.class);

    @Autowired
    private UserDetailsService userDetailsService;

    private UserService userService;
    @Autowired
    private ProductService productService;


    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping( "/")
    public String homepage(Model model, Principal principal) {
        List<Product> product = productService.findAllProducts();
        model.addAttribute("products", product);
        if(principal !=null) {
            UserDetails userDetails = userDetailsService.loadUserByUsername(principal.getName());
            model.addAttribute("userdetail", userDetails);
        } else {
            model.addAttribute("userdetail", null);
        }
        model.addAttribute("isAuthenticated", principal != null);
        return "index";
    }
//
//    //najwa tambah, call index html
//    @GetMapping("/index")
//    public String homepage(Model model, Principal principal) {
//        UserDetails userDetails = userDetailsService.loadUserByUsername(principal.getName());
//        model.addAttribute("userdetail", userDetails);
//        return "index";
//    }

    @GetMapping("/login")
    public String login(Model model, UserDto userDto) {
        model.addAttribute("user", userDto);
        return "login";
    }

    //handler method to handle user registration form request
    @GetMapping("/register")
    public String showRegistrationForm(Model model, UserDto userDto) {
        model.addAttribute("user", userDto);
        return "register";
    }

    //handle method to handle user registration form submit request
    @PostMapping("/register")
    public String registerSava(@ModelAttribute("user") UserDto userDto, Model model) {
        User user = userService.findByUsername(userDto.getUsername());
        User user2 = userService.findByEmail(userDto.getEmail());
        if (user != null) {
            model.addAttribute("Userexist", user);
            return "register";
        }

        if (user2 != null) {
            model.addAttribute("Emailexist", user2);
            return "register";
        }
        userService.save(userDto);
        return "redirect:/register?success";
    }

    @GetMapping("/search")
    public String searchProduct(@RequestParam(name="name", required = false) String name, Model model) {
        if (name == null || name.trim().isEmpty()) {
            model.addAttribute("searchResults", new ArrayList<>());
            model.addAttribute("searchname", name);
            return "searchResult";
        }
        List<Product> searchResults = productService.searchProducts(name);
        model.addAttribute("searchResults", searchResults);
        model.addAttribute("searchname", name);
        return "searchResult";
    }
}
